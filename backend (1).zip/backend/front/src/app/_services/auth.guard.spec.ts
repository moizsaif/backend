import { Auth.Guard } from './auth.guard';

describe('Auth.Guard', () => {
  it('should create an instance', () => {
    expect(new Auth.Guard()).toBeTruthy();
  });
});
