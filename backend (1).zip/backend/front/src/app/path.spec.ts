import { Path } from './path';

describe('Path', () => {
  it('should create an instance', () => {
    expect(new Path()).toBeTruthy();
  });
});
