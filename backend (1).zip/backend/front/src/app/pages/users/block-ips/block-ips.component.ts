import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-block-ips',
  templateUrl: './block-ips.component.html',
  styleUrls: ['./block-ips.component.css']
})
export class BlockIpsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
