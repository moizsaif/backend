import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transaction-records',
  templateUrl: './transaction-records.component.html',
  styleUrls: ['./transaction-records.component.css']
})
export class TransactionRecordsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
