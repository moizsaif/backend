import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-score-history',
  templateUrl: './score-history.component.html',
  styleUrls: ['./score-history.component.css']
})
export class ScoreHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
