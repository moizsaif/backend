import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-point-system',
  templateUrl: './point-system.component.html',
  styleUrls: ['./point-system.component.css']
})
export class PointSystemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
