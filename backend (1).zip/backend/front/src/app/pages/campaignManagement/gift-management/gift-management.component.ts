import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gift-management',
  templateUrl: './gift-management.component.html',
  styleUrls: ['./gift-management.component.css']
})
export class GiftManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
