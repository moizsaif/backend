import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-net-gsm',
  templateUrl: './net-gsm.component.html',
  styleUrls: ['./net-gsm.component.css']
})
export class NetGSMComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
