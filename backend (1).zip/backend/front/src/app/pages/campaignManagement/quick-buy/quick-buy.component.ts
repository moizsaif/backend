import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quick-buy',
  templateUrl: './quick-buy.component.html',
  styleUrls: ['./quick-buy.component.css']
})
export class QuickBuyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
