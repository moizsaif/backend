import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pos-campaigns',
  templateUrl: './pos-campaigns.component.html',
  styleUrls: ['./pos-campaigns.component.css']
})
export class PosCampaignsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
