import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-package-builder',
  templateUrl: './package-builder.component.html',
  styleUrls: ['./package-builder.component.css']
})
export class PackageBuilderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
