import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-limit',
  templateUrl: './purchase-limit.component.html',
  styleUrls: ['./purchase-limit.component.css']
})
export class PurchaseLimitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
