import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-survey-management',
  templateUrl: './survey-management.component.html',
  styleUrls: ['./survey-management.component.css']
})
export class SurveyManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
