import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-design',
  templateUrl: './invoice-design.component.html',
  styleUrls: ['./invoice-design.component.css']
})
export class InvoiceDesignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
