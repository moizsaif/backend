import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blog-management',
  templateUrl: './blog-management.component.html',
  styleUrls: ['./blog-management.component.css']
})
export class BlogManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
