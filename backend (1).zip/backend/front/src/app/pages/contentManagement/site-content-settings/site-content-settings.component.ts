import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-site-content-settings',
  templateUrl: './site-content-settings.component.html',
  styleUrls: ['./site-content-settings.component.css']
})
export class SiteContentSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
