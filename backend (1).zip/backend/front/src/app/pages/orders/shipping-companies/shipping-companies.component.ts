import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-companies',
  templateUrl: './shipping-companies.component.html',
  styleUrls: ['./shipping-companies.component.css']
})
export class ShippingCompaniesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
