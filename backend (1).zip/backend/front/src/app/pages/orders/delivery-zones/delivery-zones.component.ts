import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-zones',
  templateUrl: './delivery-zones.component.html',
  styleUrls: ['./delivery-zones.component.css']
})
export class DeliveryZonesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
