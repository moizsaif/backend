import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basket-reminder',
  templateUrl: './basket-reminder.component.html',
  styleUrls: ['./basket-reminder.component.css']
})
export class BasketReminderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
