import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-additional-settings',
  templateUrl: './delivery-additional-settings.component.html',
  styleUrls: ['./delivery-additional-settings.component.css']
})
export class DeliveryAdditionalSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
