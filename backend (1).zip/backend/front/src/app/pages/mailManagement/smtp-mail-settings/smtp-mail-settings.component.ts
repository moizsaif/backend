import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smtp-mail-settings',
  templateUrl: './smtp-mail-settings.component.html',
  styleUrls: ['./smtp-mail-settings.component.css']
})
export class SmtpMailSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
