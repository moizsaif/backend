import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-templates',
  templateUrl: './mail-templates.component.html',
  styleUrls: ['./mail-templates.component.css']
})
export class MailTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
