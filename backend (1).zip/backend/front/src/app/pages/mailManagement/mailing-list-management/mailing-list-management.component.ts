import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailing-list-management',
  templateUrl: './mailing-list-management.component.html',
  styleUrls: ['./mailing-list-management.component.css']
})
export class MailingListManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
