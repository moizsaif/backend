import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailing-list-groups',
  templateUrl: './mailing-list-groups.component.html',
  styleUrls: ['./mailing-list-groups.component.css']
})
export class MailingListGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
