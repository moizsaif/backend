import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mail-management',
  templateUrl: './mail-management.component.html',
  styleUrls: ['./mail-management.component.css']
})
export class MailManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
