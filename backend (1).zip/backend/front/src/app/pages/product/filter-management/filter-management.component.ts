import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-management',
  templateUrl: './filter-management.component.html',
  styleUrls: ['./filter-management.component.css']
})
export class FilterManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
