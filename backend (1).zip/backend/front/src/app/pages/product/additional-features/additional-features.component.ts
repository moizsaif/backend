import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additional-features',
  templateUrl: './additional-features.component.html',
  styleUrls: ['./additional-features.component.css']
})
export class AdditionalFeaturesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
