import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-multiple-product-updates',
  templateUrl: './multiple-product-updates.component.html',
  styleUrls: ['./multiple-product-updates.component.css']
})
export class MultipleProductUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
