import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-statistics',
  templateUrl: './payment-statistics.component.html',
  styleUrls: ['./payment-statistics.component.css']
})
export class PaymentStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
