import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rated-products',
  templateUrl: './rated-products.component.html',
  styleUrls: ['./rated-products.component.css']
})
export class RatedProductsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
