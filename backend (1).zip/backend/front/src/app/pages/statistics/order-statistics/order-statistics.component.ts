import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-statistics',
  templateUrl: './order-statistics.component.html',
  styleUrls: ['./order-statistics.component.css']
})
export class OrderStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
