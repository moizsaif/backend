import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-statistics',
  templateUrl: './search-statistics.component.html',
  styleUrls: ['./search-statistics.component.css']
})
export class SearchStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
