import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-discount-requests',
  templateUrl: './discount-requests.component.html',
  styleUrls: ['./discount-requests.component.css']
})
export class DiscountRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
