import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tape-users',
  templateUrl: './tape-users.component.html',
  styleUrls: ['./tape-users.component.css']
})
export class TapeUsersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
