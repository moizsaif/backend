import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visit-statistics',
  templateUrl: './visit-statistics.component.html',
  styleUrls: ['./visit-statistics.component.css']
})
export class VisitStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
