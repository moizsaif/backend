import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-summary-statistics',
  templateUrl: './summary-statistics.component.html',
  styleUrls: ['./summary-statistics.component.css']
})
export class SummaryStatisticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
