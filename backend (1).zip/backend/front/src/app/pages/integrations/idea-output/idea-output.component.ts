import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-idea-output',
  templateUrl: './idea-output.component.html',
  styleUrls: ['./idea-output.component.css']
})
export class IdeaOutputComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
