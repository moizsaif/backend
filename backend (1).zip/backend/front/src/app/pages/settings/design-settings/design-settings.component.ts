import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-design-settings',
  templateUrl: './design-settings.component.html',
  styleUrls: ['./design-settings.component.css']
})
export class DesignSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
