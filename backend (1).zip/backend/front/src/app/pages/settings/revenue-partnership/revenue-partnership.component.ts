import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-revenue-partnership',
  templateUrl: './revenue-partnership.component.html',
  styleUrls: ['./revenue-partnership.component.css']
})
export class RevenuePartnershipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
