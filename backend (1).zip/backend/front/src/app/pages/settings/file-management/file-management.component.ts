import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-management',
  templateUrl: './file-management.component.html',
  styleUrls: ['./file-management.component.css']
})
export class FileManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
