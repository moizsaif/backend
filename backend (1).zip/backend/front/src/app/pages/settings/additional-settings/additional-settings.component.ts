import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-additional-settings',
  templateUrl: './additional-settings.component.html',
  styleUrls: ['./additional-settings.component.css']
})
export class AdditionalSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
