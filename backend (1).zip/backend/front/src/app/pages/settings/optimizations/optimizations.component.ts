import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-optimizations',
  templateUrl: './optimizations.component.html',
  styleUrls: ['./optimizations.component.css']
})
export class OptimizationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
