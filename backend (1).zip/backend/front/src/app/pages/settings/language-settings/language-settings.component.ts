import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-language-settings',
  templateUrl: './language-settings.component.html',
  styleUrls: ['./language-settings.component.css']
})
export class LanguageSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
