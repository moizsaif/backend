import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ad-settings',
  templateUrl: './ad-settings.component.html',
  styleUrls: ['./ad-settings.component.css']
})
export class AdSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
