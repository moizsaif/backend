import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertising-center',
  templateUrl: './advertising-center.component.html',
  styleUrls: ['./advertising-center.component.css']
})
export class AdvertisingCenterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
