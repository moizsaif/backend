import { HomeMenu } from './home-menu';

describe('HomeMenu', () => {
  it('should create an instance', () => {
    expect(new HomeMenu()).toBeTruthy();
  });
});
