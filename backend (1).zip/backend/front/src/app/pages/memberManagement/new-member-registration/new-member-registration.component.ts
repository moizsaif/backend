import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-member-registration',
  templateUrl: './new-member-registration.component.html',
  styleUrls: ['./new-member-registration.component.css']
})
export class NewMemberRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
