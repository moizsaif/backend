import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-member-group',
  templateUrl: './add-member-group.component.html',
  styleUrls: ['./add-member-group.component.css']
})
export class AddMemberGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
