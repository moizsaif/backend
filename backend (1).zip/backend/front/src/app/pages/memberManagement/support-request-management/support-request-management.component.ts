import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-support-request-management',
  templateUrl: './support-request-management.component.html',
  styleUrls: ['./support-request-management.component.css']
})
export class SupportRequestManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
