import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-member-group',
  templateUrl: './member-group.component.html',
  styleUrls: ['./member-group.component.css']
})
export class MemberGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
