module.exports = {
  secret: "k2i-secret-key"
};
